const C3 = self.C3;
self.C3_GetObjectRefTable = function () {
	return [
		C3.Plugins.Sprite,
		C3.Behaviors.Platform,
		C3.Behaviors.scrollto,
		C3.Behaviors.bound,
		C3.Behaviors.solid,
		C3.Plugins.TiledBg,
		C3.Plugins.Keyboard,
		C3.Plugins.Tilemap,
		C3.Plugins.System.Cnds.IsGroupActive,
		C3.Plugins.Keyboard.Cnds.OnKey,
		C3.Plugins.Sprite.Acts.SetMirrored,
		C3.Behaviors.Platform.Cnds.IsOnFloor,
		C3.Behaviors.Platform.Cnds.CompareSpeed,
		C3.Plugins.Sprite.Acts.SetAnim,
		C3.Behaviors.Platform.Cnds.IsJumping,
		C3.Behaviors.Platform.Cnds.IsFalling,
		C3.Plugins.Sprite.Cnds.OnCollision,
		C3.Plugins.Sprite.Acts.SubInstanceVar,
		C3.Plugins.Sprite.Cnds.CompareInstanceVar,
		C3.Plugins.Sprite.Acts.Destroy,
		C3.Plugins.System.Acts.Wait,
		C3.Plugins.System.Acts.RestartLayout
	];
};
self.C3_JsPropNameTable = [
	{Plataforma: 0},
	{DesplazarHasta: 0},
	{RestringidoALaEscena: 0},
	{Sprite: 0},
	{Sprite2: 0},
	{Sólido: 0},
	{Sprite3: 0},
	{Sprite4: 0},
	{FondoEnMosaico: 0},
	{Sprite5: 0},
	{vida: 0},
	{pingu: 0},
	{Teclado: 0},
	{FondoEnMosaico2: 0},
	{MapaDeTeselas: 0},
	{FondoEnMosaico3: 0},
	{FondoEnMosaico4: 0},
	{picos: 0}
];

self.InstanceType = {
	Sprite: class extends self.ISpriteInstance {},
	Sprite2: class extends self.ISpriteInstance {},
	Sprite3: class extends self.ISpriteInstance {},
	Sprite4: class extends self.ISpriteInstance {},
	FondoEnMosaico: class extends self.ITiledBackgroundInstance {},
	Sprite5: class extends self.ISpriteInstance {},
	pingu: class extends self.ISpriteInstance {},
	Teclado: class extends self.IInstance {},
	FondoEnMosaico2: class extends self.ITiledBackgroundInstance {},
	MapaDeTeselas: class extends self.ITilemapInstance {},
	FondoEnMosaico3: class extends self.ITiledBackgroundInstance {},
	FondoEnMosaico4: class extends self.ITiledBackgroundInstance {},
	picos: class extends self.ITiledBackgroundInstance {}
}